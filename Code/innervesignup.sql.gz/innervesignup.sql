-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2018 at 01:14 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `innervesignup`
--

-- --------------------------------------------------------

--
-- Table structure for table `enroll`
--

CREATE TABLE `enroll` (
  `Name` varchar(50) NOT NULL,
  `Program` text NOT NULL,
  `Amount` int(5) NOT NULL,
  `Age` int(2) NOT NULL,
  `Gender` text NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Adr` longtext NOT NULL,
  `Mode` text NOT NULL,
  `Cname` varchar(50) NOT NULL,
  `Exp` date NOT NULL,
  `Cnum` int(20) NOT NULL,
  `cvv` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enroll`
--

INSERT INTO `enroll` (`Name`, `Program`, `Amount`, `Age`, `Gender`, `Mobile`, `Email`, `Adr`, `Mode`, `Cname`, `Exp`, `Cnum`, `cvv`) VALUES
('Aakanksha Verma', 'as', 0, 20, 'female', '2147483647', 'aakankshaverma31@gmail.com', '16 Gangotri Apartments, Fb-Block, Vikas Puri', 'ptm', '', '0000-00-00', 0, 0),
('Aakanksha Verma', 'fp', 0, 25, 'female', '2147483647', 'aakankshaverma31@gmail.com', '16 Gangotri Apartments, Fb-Block, Vikas Puri', 'ptm', '', '0000-00-00', 0, 0),
('Deepak', 'pc', 0, 21, 'male', '9650659498', 'dklovesav@gmail.com', 'sdjfnsdofndsofndslk,', 'dc', 'DEEPAK KUNDRA', '2023-03-03', 2147483647, 149),
('Aastha', 'as', 2500, 16, 'female', '100', 'aasrit@gmail.com', '6/34 tilak nagar', 'ptm', '', '0000-00-00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sign`
--

CREATE TABLE `sign` (
  `Email` varchar(50) NOT NULL,
  `regularity` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign`
--

INSERT INTO `sign` (`Email`, `regularity`) VALUES
('deepakk30@gmail.com', ''),
('dnsndsan@hsjafkjdsf.com', ''),
('nbhjbj', 'Weekly'),
('dkndl', 'Daily');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
